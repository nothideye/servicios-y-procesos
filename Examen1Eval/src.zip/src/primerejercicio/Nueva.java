package primerejercicio;

public class Nueva {

}
